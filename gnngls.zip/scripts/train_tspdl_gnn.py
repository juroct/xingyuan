#!/usr/bin/env python
# coding: utf-8

"""
Train a GNN model for TSPDL.

This script trains a GNN model to predict edge properties for TSPDL problems.
"""

import argparse
import datetime
import json
import os
import pathlib
import uuid

import dgl
import torch
import torch.nn as nn
import torch.optim as optim
import tqdm.auto as tqdm
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from gnngls import TSPDLDataset, TSPDLEdgeModel


def train(model, data_loader, criterion, optimizer, device):
    """
    Train the model for one epoch.

    Args:
        model: Model to train
        data_loader: Data loader
        criterion: Loss function
        optimizer: Optimizer
        device: Device to use

    Returns:
        epoch_loss: Average loss for the epoch
    """
    model.train()

    epoch_loss = 0
    for batch_i, batch in enumerate(data_loader):
        batch_graphs = batch[0].to(device)
        batch_labels = batch[1].to(device)

        # Forward pass
        edge_feats = batch_graphs.edata['features']
        node_feats = torch.cat([
            batch_graphs.ndata['coords'],
            batch_graphs.ndata['demand'],
            batch_graphs.ndata['draft_limit']
        ], dim=1)

        outputs = model(batch_graphs, edge_feats, node_feats).squeeze()

        # Calculate loss
        loss = criterion(outputs, batch_labels)

        # Backward pass and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()

    epoch_loss /= (batch_i + 1)
    return epoch_loss


def validate(model, data_loader, criterion, device):
    """
    Validate the model.

    Args:
        model: Model to validate
        data_loader: Data loader
        criterion: Loss function
        device: Device to use

    Returns:
        val_loss: Average validation loss
    """
    model.eval()

    val_loss = 0
    with torch.no_grad():
        for batch_i, batch in enumerate(data_loader):
            batch_graphs = batch[0].to(device)
            batch_labels = batch[1].to(device)

            # Forward pass
            edge_feats = batch_graphs.edata['features']
            node_feats = torch.cat([
                batch_graphs.ndata['coords'],
                batch_graphs.ndata['demand'],
                batch_graphs.ndata['draft_limit']
            ], dim=1)

            outputs = model(batch_graphs, edge_feats, node_feats).squeeze()

            # Calculate loss
            loss = criterion(outputs, batch_labels)

            val_loss += loss.item()

    val_loss /= (batch_i + 1)
    return val_loss


def save_checkpoint(model, optimizer, epoch, train_loss, val_loss, save_path):
    """
    Save model checkpoint.

    Args:
        model: Model to save
        optimizer: Optimizer
        epoch: Current epoch
        train_loss: Training loss
        val_loss: Validation loss
        save_path: Path to save the checkpoint
    """
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'train_loss': train_loss,
        'val_loss': val_loss
    }, save_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train GNN model for TSPDL")
    parser.add_argument("data_dir", type=str, help="Directory containing the dataset")
    parser.add_argument("output_dir", type=str, help="Directory to save the model")
    parser.add_argument("--embed_dim", type=int, default=128, help="Embedding dimension")
    parser.add_argument("--n_layers", type=int, default=3, help="Number of GNN layers")
    parser.add_argument("--n_heads", type=int, default=8, help="Number of attention heads")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size")
    parser.add_argument("--lr", type=float, default=0.001, help="Learning rate")
    parser.add_argument("--n_epochs", type=int, default=100, help="Number of epochs")
    parser.add_argument("--patience", type=int, default=10, help="Patience for early stopping")
    parser.add_argument("--use_gpu", action="store_true", help="Use GPU if available")

    args = parser.parse_args()

    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)

    # Set device
    device = torch.device("cuda" if args.use_gpu and torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Load dataset
    train_dataset = TSPDLDataset(os.path.join(args.data_dir, "train", "train.txt"))
    val_dataset = TSPDLDataset(os.path.join(args.data_dir, "val", "val.txt"))

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=lambda batch: (dgl.batch([x[0] for x in batch]), torch.cat([x[1] for x in batch]))
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=lambda batch: (dgl.batch([x[0] for x in batch]), torch.cat([x[1] for x in batch]))
    )

    # Create model
    model = TSPDLEdgeModel(
        in_dim=3,  # [distance, in_tour, draft_limit_respected]
        embed_dim=args.embed_dim,
        out_dim=1,
        n_layers=args.n_layers,
        n_heads=args.n_heads
    ).to(device)

    # Create optimizer and loss function
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    criterion = nn.BCEWithLogitsLoss()

    # Create tensorboard writer
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    run_name = f"tspdl_gnn_{timestamp}_{uuid.uuid4().hex[:8]}"
    log_dir = os.path.join(args.output_dir, "logs", run_name)
    os.makedirs(log_dir, exist_ok=True)
    writer = SummaryWriter(log_dir)

    # Save parameters
    params = vars(args)
    with open(os.path.join(args.output_dir, "params.json"), "w") as f:
        json.dump(params, f, indent=4)

    # Train model
    best_val_loss = float("inf")
    patience_counter = 0

    for epoch in range(args.n_epochs):
        # Train
        train_loss = train(model, train_loader, criterion, optimizer, device)

        # Validate
        val_loss = validate(model, val_loader, criterion, device)

        # Log
        writer.add_scalar("Loss/train", train_loss, epoch)
        writer.add_scalar("Loss/val", val_loss, epoch)

        print(f"Epoch {epoch+1}/{args.n_epochs} - Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")

        # Save checkpoint
        save_checkpoint(
            model, optimizer, epoch, train_loss, val_loss,
            os.path.join(args.output_dir, f"checkpoint_{epoch+1}.pt")
        )

        # Early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0

            # Save best model
            save_checkpoint(
                model, optimizer, epoch, train_loss, val_loss,
                os.path.join(args.output_dir, "best_model.pt")
            )
        else:
            patience_counter += 1

        if patience_counter >= args.patience:
            print(f"Early stopping after {epoch+1} epochs")
            break

    # Save final model
    save_checkpoint(
        model, optimizer, args.n_epochs, train_loss, val_loss,
        os.path.join(args.output_dir, "final_model.pt")
    )

    print(f"Training completed. Best validation loss: {best_val_loss:.4f}")
    print(f"Model saved to {args.output_dir}")
